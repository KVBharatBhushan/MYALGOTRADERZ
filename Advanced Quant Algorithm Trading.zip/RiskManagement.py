class RiskManagement :
    StopLoss = 20
    Targetpoint = 50
    IsAllowed = True

    EntryTime = 91400
    ExitTime = 152600

    Total_OpenTrades_AtaTime = 16
