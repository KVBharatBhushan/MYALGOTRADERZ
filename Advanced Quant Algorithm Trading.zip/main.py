import QuantAlgo1 as Q

if __name__ == '__main__' :
    print( "starting.." )
    run1 = Q.IndexAnalysis( )
    run1.Run_StrategyAnalysis( print_tocsv = True )
    run1.Summary( )
